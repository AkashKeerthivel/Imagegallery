import React from "react";
import Buttonpanel from "./Buttonpanel";
import Imagegallery from "./Imagegallery";
import "./App.css";

class App extends React.Component{
    constructor(props) {

        super(props);
        this.state = {
            cate : 'all'
        }
    }
    receivecate = (cate)=>{
        this.setState({cate:cate})
    }

    render(){
        return(
            <div>
                <Buttonpanel receivecate = {this.receivecate}/>
                <Imagegallery cate = {this.state.cate}/>
            </div>
        )
    }
}
export default App;