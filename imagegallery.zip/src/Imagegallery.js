import React from "react";

class Imagegallery extends React.Component {

    constructor(props) {

        super(props);
    }

    arr1 = [
        {
            category: 'all fl',
            image:"https://images.pexels.com/photos/1408221/pexels-photo-1408221.jpeg?auto=compress&cs=tinysrgb&w=600"
        },
        {
            category: 'all bi',
            image:"https://images.pexels.com/photos/34006/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=600"
        },
        {
            category: 'all lp',
            image:"https://images.pexels.com/photos/238118/pexels-photo-238118.jpeg?auto=compress&cs=tinysrgb&w=600"
        },
        {
            category: 'all bi',
            image:"https://images.pexels.com/photos/341499/pexels-photo-341499.jpeg?auto=compress&cs=tinysrgb&w=600"
        },
       
        {
            category: 'all lp',
            image:"https://images.pexels.com/photos/1006293/pexels-photo-1006293.jpeg?auto=compress&cs=tinysrgb&w=600"
        },
        {
            category: 'all bi',
            image:"https://images.pexels.com/photos/1413412/pexels-photo-1413412.jpeg?auto=compress&cs=tinysrgb&w=600"
        },
        {
            category: 'all fl',
            image:"https://images.pexels.com/photos/1563650/pexels-photo-1563650.jpeg?auto=compress&cs=tinysrgb&w=600"
        },
        
        
        {
            category: 'all lp',
            image:"https://images.pexels.com/photos/459653/pexels-photo-459653.jpeg?auto=compress&cs=tinysrgb&w=600"
        },
        { 
            category: 'all bi',
            image:"https://images.pexels.com/photos/819805/pexels-photo-819805.jpeg?auto=compress&cs=tinysrgb&w=600"
        },
        {
            category: 'all lp',
            image:"https://images.pexels.com/photos/40185/mac-freelancer-macintosh-macbook-40185.jpeg?auto=compress&cs=tinysrgb&w=600"
        },
        {
            category: 'all fl',
            image:"https://images.pexels.com/photos/1233414/pexels-photo-1233414.jpeg?auto=compress&cs=tinysrgb&w=600"
        },
        {
            category: 'all lp',
            image:"https://images.pexels.com/photos/5793953/pexels-photo-5793953.jpeg?auto=compress&cs=tinysrgb&w=600"
        },
        {
            category: 'all fl',
            image:"https://images.pexels.com/photos/132468/pexels-photo-132468.jpeg?auto=compress&cs=tinysrgb&w=600"
        },
        {
            category: 'all bi',
            image:"https://images.pexels.com/photos/2116475/pexels-photo-2116475.jpeg?auto=compress&cs=tinysrgb&w=600"
        },
        {
            category: 'all fl',
            image:"https://images.pexels.com/photos/992734/pexels-photo-992734.jpeg?auto=compress&cs=tinysrgb&w=600"
        },
        
    ]
    render() {
        let html2 = this.arr1.map((val) => {
            if(val.category.includes(this.props.cate)){
                
                return (
                    <div className="image">
                        <img src={val.image} alt="image"/>
                    </div> 
                )
            }
            else{
                return(
                    null
                )
            }
            

        })

        return (
            <div className="images">
                {html2}
            </div>
        )


    }
}


export default Imagegallery;