import React from "react";

class Buttonpanel extends React.Component{
    constructor(props){
        super(props);
    }


buttonclick=(cate)=>{
    this.props.receivecate(cate);
}


    render(){

        
        return(
            <div className="buttons">
                <button className="bn29" onClick={()=>{this.buttonclick('all')}}>All</button>
                <button className="bn29" onClick={()=>{this.buttonclick('fl')}}>Flowers</button>
                <button className="bn29" onClick={()=>{this.buttonclick('bi')}}>Bikes</button>
                <button className="bn29" onClick={()=>{this.buttonclick('lp')}}>Laptops</button>
            </div>
        )
    }
}


export default Buttonpanel;